import os, yaml, pandas as pd, numpy as np
from ..metrics.network_metrics import reciprocity_stats, branching_factor, equality_of_voice, assortativity, dc_bi_analytic
from ..utils.io_utils import save_parquet, ensure_dir
from ..utils.anchor_utils import build_control_anchor_map, median_timestamp
from ..models.prosocial import ProsocialAnalyzer

ART = "artifacts/outcomes"

def run():
    cfg = yaml.safe_load(open("config.yaml", "r", encoding="utf-8"))
    edges = pd.read_parquet("artifacts/threads/edges.parquet")
    tstars = pd.read_parquet("artifacts/threads/tstars.parquet")
    meta = pd.read_parquet("artifacts/threads/thread_meta.parquet")
    users = pd.read_parquet("artifacts/ingested/users.parquet")
    posts = pd.read_parquet("artifacts/ingested/posts.parquet")
    comments = pd.read_parquet("artifacts/ingested/comments.parquet")

    # Optional: matched pairs used to assign pseudo anchor times for controls
    try:
        pairs = pd.read_parquet("artifacts/matching/matched_pairs.parquet")
    except Exception:
        pairs = pd.DataFrame()

    # Build user attribute table
    ua = users[["_id","verified","followers_count","gender","location","ip_location","mbrank","mbtype","created_at","statuses_count","sunshine_credit"]].copy()
    ua.rename(columns={"_id":"user_id","ip_location":"province"}, inplace=True)
    ua["gender"] = ua["gender"].fillna("unk").replace({"": "unk"})
    ua["province"] = ua["province"].fillna("unk").replace({"": "unk"})

    # Prosocial analyser (lexicon + classifier if available)
    prosocial = ProsocialAnalyzer.from_config(cfg, comments)

    # Window settings
    time_win = int(cfg.get("time_window_minutes", 120))
    K = int(cfg.get("edge_budget_K", 20))
    min_pre = int(cfg.get("edge_budget_min_pre", K))
    min_post = int(cfg.get("edge_budget_min_post", K))
    min_inc_pre = int(cfg.get("incumbent_edge_min_pre", 1))
    min_inc_post = int(cfg.get("incumbent_edge_min_post", 1))
    include_op = bool(cfg.get("incumbent_include_op", True))

    # Control anchor strategy label (for traceability in outputs)
    control_strategy = str(cfg.get("control_anchor_strategy", "matched_median") or "matched_median").strip().lower()
    if control_strategy not in {"matched_median", "matched_median_latency"}:
        control_strategy = "matched_median"

    # Anchors
    tstars_map = dict(zip(tstars["mblogid"].astype(str), tstars["tstar"]))
    created_at_map = {}
    if not meta.empty and "mblogid" in meta.columns and "created_at" in meta.columns:
        created_at_map = dict(zip(meta["mblogid"].astype(str), meta["created_at"]))
    control_anchor_map, control_n_matches = build_control_anchor_map(
        pairs,
        tstars_map,
        strategy=str(cfg.get("control_anchor_strategy", "matched_median")),
        created_at_map=created_at_map,
    )

    # Thread -> OP lookup
    op_map = {}
    if not meta.empty and "mblogid" in meta.columns and "op_id" in meta.columns:
        op_map = dict(zip(meta["mblogid"], meta["op_id"]))

    # Pre-sort comments and build group index for fast per-thread lookup (avoid O(N^2) filtering)
    comments_sorted = comments.sort_values(["root_post_mblogid", "created_at"]) if not comments.empty else comments
    comments_groups = comments_sorted.groupby("root_post_mblogid", sort=False) if not comments_sorted.empty else None

    rows = []
    if edges.empty:
        out = pd.DataFrame()
    else:
        # Make sure edges are ordered for head/tail slicing
        sort_cols = ["root_post_mblogid", "created_at"]
        if "edge_idx" in edges.columns:
            sort_cols.append("edge_idx")
        edges_sorted = edges.sort_values(sort_cols)

        def _get_thread_comments(mid: str) -> pd.DataFrame:
            if comments_groups is None:
                return comments.iloc[0:0]
            try:
                return comments_groups.get_group(mid)
            except KeyError:
                return comments.iloc[0:0]

        def _human_edges(df_edges: pd.DataFrame) -> pd.DataFrame:
            if df_edges.empty:
                return df_edges
            if "is_human_edge" in df_edges.columns:
                return df_edges[df_edges["is_human_edge"]].copy()
            # Backward-compatible fallback (older artifacts)
            if "is_agent" in df_edges.columns:
                return df_edges[~df_edges["is_agent"]].copy()
            return df_edges.copy()

        def _slice_time_window(df_edges: pd.DataFrame, anchor_time: pd.Timestamp) -> tuple[pd.DataFrame, pd.DataFrame]:
            if df_edges.empty or pd.isna(anchor_time):
                return df_edges.iloc[0:0], df_edges.iloc[0:0]
            window = pd.Timedelta(minutes=time_win)
            pre = df_edges[(df_edges["created_at"] < anchor_time) & (df_edges["created_at"] >= anchor_time - window)]
            post = df_edges[(df_edges["created_at"] >= anchor_time) & (df_edges["created_at"] <= anchor_time + window)]
            return pre, post

        def _slice_edge_budget(df_edges: pd.DataFrame, anchor_time: pd.Timestamp, k: int) -> tuple[pd.DataFrame, pd.DataFrame]:
            if df_edges.empty or pd.isna(anchor_time) or k <= 0:
                return df_edges.iloc[0:0], df_edges.iloc[0:0]
            df_edges = df_edges.sort_values("created_at")
            pre = df_edges[df_edges["created_at"] < anchor_time].tail(k)
            post = df_edges[df_edges["created_at"] >= anchor_time].head(k)
            return pre, post

        def _incumbent_only_edges(
            human_df_edges: pd.DataFrame,
            anchor_time: pd.Timestamp,
            op_id: str | None,
        ) -> tuple[pd.DataFrame, set]:
            if human_df_edges.empty or pd.isna(anchor_time):
                return human_df_edges.iloc[0:0], set()
            pre_hist = human_df_edges[human_df_edges["created_at"] < anchor_time]
            incumbents = set(pd.unique(pre_hist[["u", "v"]].values.ravel("K")))
            if include_op and op_id is not None:
                incumbents.add(op_id)
            if not incumbents:
                return human_df_edges.iloc[0:0], set()
            inc_edges = human_df_edges[
                human_df_edges["u"].isin(incumbents) & human_df_edges["v"].isin(incumbents)
            ]
            return inc_edges, incumbents

        def metrics_for(df_edges: pd.DataFrame, op_id: str | None):
            if df_edges is None or df_edges.empty:
                return {
                    "R": np.nan,
                    "R_weighted": np.nan,
                    "R_with_op": np.nan,
                    "R_weighted_with_op": np.nan,
                    "BF": np.nan,
                    "BF_proxy": np.nan,
                    "Gini": np.nan,
                    "Assort_gender": np.nan,
                    "Assort_province": np.nan,
                    "DCBI_gender": np.nan,
                    "DCBI_province": np.nan,
                }
            base = df_edges[["u", "v"]].copy()
            R = reciprocity_stats(
                base,
                op_id=op_id,
                exclude_op=cfg.get("exclude_op_in_reciprocity_main", True),
            )
            R_with_op = reciprocity_stats(base, op_id=op_id, exclude_op=False)
            BF = branching_factor(base, op_id=op_id)
            G = equality_of_voice(base)
            nodes = pd.unique(base[["u", "v"]].values.ravel("K"))
            uattr = ua[ua["user_id"].isin(nodes)][["user_id", "gender", "province", "verified"]].copy()
            A_gender = assortativity(base, uattr[["user_id", "gender"]], "gender")
            A_prov = assortativity(base, uattr[["user_id", "province"]], "province")
            DCBI_gender, _ = dc_bi_analytic(base, uattr[["user_id", "gender"]], "gender")
            DCBI_prov, _ = dc_bi_analytic(base, uattr[["user_id", "province"]], "province")
            out = {}
            out.update(R)
            out["R_with_op"] = R_with_op.get("R", np.nan)
            out["R_weighted_with_op"] = R_with_op.get("R_weighted", np.nan)
            out.update(BF)
            out.update(G)
            out["Assort_gender"] = A_gender
            out["Assort_province"] = A_prov
            out["DCBI_gender"] = DCBI_gender
            out["DCBI_province"] = DCBI_prov
            return out

        max_threads = int(cfg.get("debug_max_threads", 0) or 0)
        processed = 0
        for mblogid, T_edges in edges_sorted.groupby("root_post_mblogid", sort=False):
            if max_threads and processed >= max_threads:
                break
            tstar = tstars_map.get(mblogid, pd.NaT)
            op_id = op_map.get(mblogid)

            # Anchor time:
            # - treated: t*
            # - matched controls: pseudo anchor from matched treated counterparts (see anchor_utils)
            # - unmatched controls: optional fallback (default: thread median edge time)
            anchor_time = tstar
            anchor_source = "tstar" if not pd.isna(tstar) else "control"
            anchor_n = 0
            if pd.isna(anchor_time):
                anchor_time = control_anchor_map.get(mblogid, pd.NaT)
                anchor_n = int(control_n_matches.get(mblogid, 0))
                if not pd.isna(anchor_time):
                    anchor_source = control_strategy
                else:
                    # Fallback (configurable): median edge time within this thread (human edges preferred)
                    fb = str(cfg.get("control_anchor_fallback", "thread_median_edge") or "thread_median_edge").strip().lower()
                    if fb in {"thread_median_edge", "median_edge", "thread_median"}:
                        human_tmp = _human_edges(T_edges)
                        ordered = human_tmp["created_at"].sort_values()
                        anchor_time = median_timestamp(ordered)
                        anchor_source = "thread_median_edge" if not pd.isna(anchor_time) else "missing"
                    else:
                        anchor_time = pd.NaT
                        anchor_source = "missing"

            # Human-only edges (remove agent from both endpoints)
            H_edges = _human_edges(T_edges).sort_values("created_at")

            # Windows:
            # (A) Budget slices (human-only): last K pre, first K post
            pre_budget_edges, post_budget_edges = _slice_edge_budget(H_edges, anchor_time, K)

            # (B) robustness: human-only + time window (±time_win)
            pre_time_edges, post_time_edges = _slice_time_window(H_edges, anchor_time)

            # (C) main metrics are computed on incumbent-only edges *within the budget slices*
            # This aligns "fixed interaction budget" (K) with "incumbent rewiring" (subset).
            _, incumbents = _incumbent_only_edges(H_edges, anchor_time, op_id)
            pre_main_edges = pre_budget_edges[
                pre_budget_edges["u"].isin(incumbents) & pre_budget_edges["v"].isin(incumbents)
            ].copy()
            post_main_edges = post_budget_edges[
                post_budget_edges["u"].isin(incumbents) & post_budget_edges["v"].isin(incumbents)
            ].copy()

            # Metrics
            all_m = metrics_for(H_edges, op_id)
            pre_m = metrics_for(pre_main_edges, op_id)
            post_m = metrics_for(post_main_edges, op_id)
            pre_budget_m = metrics_for(pre_budget_edges, op_id)
            post_budget_m = metrics_for(post_budget_edges, op_id)
            pre_time_m = metrics_for(pre_time_edges, op_id)
            post_time_m = metrics_for(post_time_edges, op_id)

            # Comments + prosocial (keep legacy names: pre_/post_ for prosocial remain time-window around anchor)
            T_comments = _get_thread_comments(mblogid)
            if T_comments is None or T_comments.empty or pd.isna(anchor_time):
                pre_c = T_comments.iloc[0:0] if T_comments is not None else None
                post_c = T_comments.iloc[0:0] if T_comments is not None else None
            else:
                window = pd.Timedelta(minutes=time_win)
                pre_c = T_comments[(T_comments["created_at"] < anchor_time) & (T_comments["created_at"] >= anchor_time - window)]
                post_c = T_comments[(T_comments["created_at"] >= anchor_time) & (T_comments["created_at"] <= anchor_time + window)]

            P_all = prosocial.aggregate(T_comments, "content")
            P_pre = prosocial.aggregate(pre_c, "content")
            P_post = prosocial.aggregate(post_c, "content")

            # Coverage indicators
            n_pre_main = int(len(pre_main_edges))
            n_post_main = int(len(post_main_edges))
            n_pre_budget = int(len(pre_budget_edges))
            n_post_budget = int(len(post_budget_edges))
            budget_ok = int((n_pre_budget >= min_pre) and (n_post_budget >= min_post))
            main_ok = int(
                budget_ok
                and (n_pre_main >= min_inc_pre)
                and (n_post_main >= min_inc_post)
            )

            row = {
                "mblogid": mblogid,
                "tstar": tstar,
                "anchor_time": anchor_time,
                "anchor_source": anchor_source,
                "anchor_n_matches": anchor_n,
                "n_edges": int(len(H_edges)),
                "n_edges_total": int(len(T_edges)),
                "n_incumbents_pre": int(len(incumbents)),
                "n_pre_budget_edges": n_pre_budget,
                "n_post_budget_edges": n_post_budget,
                "budget_ok": budget_ok,
                "n_pre_main_edges": n_pre_main,
                "n_post_main_edges": n_post_main,
                "main_budget_ok": main_ok,
                **{f"all_{k}": v for k, v in all_m.items()},
                # Main outputs (network): incumbent-only + edge budget
                **{f"pre_{k}": v for k, v in pre_m.items()},
                **{f"post_{k}": v for k, v in post_m.items()},
                # Robustness: human-only + edge budget
                **{f"pre_budget_{k}": v for k, v in pre_budget_m.items()},
                **{f"post_budget_{k}": v for k, v in post_budget_m.items()},
                # Robustness: human-only + time window
                **{f"pre_time_{k}": v for k, v in pre_time_m.items()},
                **{f"post_time_{k}": v for k, v in post_time_m.items()},
                # Prosocial (legacy: time window around anchor)
                **{f"all_{k}": v for k, v in P_all.items()},
                **{f"pre_{k}": v for k, v in P_pre.items()},
                **{f"post_{k}": v for k, v in P_post.items()},
            }
            rows.append(row)
            processed += 1

        out = pd.DataFrame(rows)

    # Add post-pre deltas for any metric with both columns
    if out is not None and not out.empty:
        # Save anchors separately for reuse/debugging
        try:
            ensure_dir("artifacts/matching")
            save_parquet(
                out[["mblogid", "tstar", "anchor_time", "anchor_source", "anchor_n_matches"]],
                "artifacts/matching/anchors.parquet",
            )
        except Exception:
            pass

        for col in out.columns:
            if col.startswith("post_"):
                metric = col[5:]
                pre_col = f"pre_{metric}"
                if pre_col in out.columns:
                    out[f"d_{metric}"] = out[col] - out[pre_col]

    ensure_dir(ART)
    save_parquet(out, f"{ART}/outcomes.parquet")
    print("Outcomes computed and saved.")

if __name__ == "__main__":
    run()
